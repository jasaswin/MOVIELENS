import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import PdfViewer from './components/PdfViewer';
import ChartPage1 from './pages/ChartPage1';
import ChartPage2 from './pages/ChartPage2';
import ChartPage3 from './pages/ChartPage3';
import ChartPage4 from './pages/ChartPage4';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/pdf" element={<PdfViewer />} />
        <Route path="/chart1" element={<ChartPage1 />} />
        <Route path="/chart2" element={<ChartPage2 />} />
        <Route path="/chart3" element={<ChartPage3 />} />
        <Route path="/chart4" element={<ChartPage4 />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
