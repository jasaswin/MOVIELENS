import { Box, Typography } from '@mui/material';

const ChartPage3 = () => (
  <Box sx={ p: 4 }>
    <Typography variant="h5" gutterBottom>Chart 3</Typography>
    <img src={`/assets/chart3.png`} alt="Chart 3" style={ maxWidth: '100%' } />
    <Typography variant="body1" sx={ mt: 2 }>
      Brief insights or analytical summary about Chart 3 goes here.
    </Typography>
  </Box>
);

export default ChartPage3;
