import { Box, Typography } from '@mui/material';

const ChartPage4 = () => (
  <Box sx={ p: 4 }>
    <Typography variant="h5" gutterBottom>Chart 4</Typography>
    <img src={`/assets/chart4.png`} alt="Chart 4" style={ maxWidth: '100%' } />
    <Typography variant="body1" sx={ mt: 2 }>
      Brief insights or analytical summary about Chart 4 goes here.
    </Typography>
  </Box>
);

export default ChartPage4;
