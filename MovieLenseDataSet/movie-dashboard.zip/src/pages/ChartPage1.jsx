import { Box, Typography } from '@mui/material';

const ChartPage1 = () => (
  <Box sx={ p: 4 }>
    <Typography variant="h5" gutterBottom>Chart 1</Typography>
    <img src={`/assets/chart1.png`} alt="Chart 1" style={ maxWidth: '100%' } />
    <Typography variant="body1" sx={ mt: 2 }>
      Brief insights or analytical summary about Chart 1 goes here.
    </Typography>
  </Box>
);

export default ChartPage1;
