import { Box, Typography, Grid, Button } from '@mui/material';
import DashboardCard from '../components/DashboardCard';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();

  return (
    <Box sx={{ p: 4 }}>
      <Typography variant="h4" gutterBottom>🎬 MovieLens Dashboard</Typography>
      <Typography variant="body1" gutterBottom>
        Explore insights from movie data including ratings, genres, profits, and budget trends.
      </Typography>

      <Grid container spacing={2}>
        <DashboardCard
          title="Top Rated Movies"
          description="Explore the top 10 highest rated films."
          image="/assets/chart1.png"
          route="/chart1"
        />
        <DashboardCard
          title="Genre-wise Rating Analysis"
          description="See how different genres compare in ratings."
          image="/assets/chart2.png"
          route="/chart2"
        />
        <DashboardCard
          title="Profit Over Time"
          description="Year-wise profit trend between 2000–2014."
          image="/assets/chart3.png"
          route="/chart3"
        />
        <DashboardCard
          title="Revenue vs Budget"
          description="Compare revenue and budget for top genres."
          image="/assets/chart4.png"
          route="/chart4"
        />
      </Grid>

      <Button variant="outlined" sx={{ mt: 4 }} onClick={() => navigate('/pdf')}>View Full Report (PDF)</Button>
    </Box>
  );
};

export default Home;
