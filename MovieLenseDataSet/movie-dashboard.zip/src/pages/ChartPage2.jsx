import { Box, Typography } from '@mui/material';

const ChartPage2 = () => (
  <Box sx={ p: 4 }>
    <Typography variant="h5" gutterBottom>Chart 2</Typography>
    <img src={`/assets/chart2.png`} alt="Chart 2" style={ maxWidth: '100%' } />
    <Typography variant="body1" sx={ mt: 2 }>
      Brief insights or analytical summary about Chart 2 goes here.
    </Typography>
  </Box>
);

export default ChartPage2;
